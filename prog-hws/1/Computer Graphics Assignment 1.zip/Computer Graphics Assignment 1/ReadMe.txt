Author: Viswanath Pulle
ID: 01690370

Title: Assignment 1

Files included: 
1. Main.html
2. Algorithms-All.js
3. ReadMe.txt

Procedure:
Choose the Shape to draw
Click on the canvas to choose the ends of the Shape's vertices 
To Erase click the "CLEAR" button.
For Polygon, Enter the number of vertices  before clicking on the button 
Note: Please click the polygon button again if you want to change the number of vertices of the polygon without clearing the canvas
Please click the shape button again when Switching between the colors

Implementation:

I have implented Midpoint algorithm for all the shapes listed for the assignment
for Extra credit:
I stylized the button labels, the transitions on the background
I also implemented the click feature 
I implementd the ability to choose colors


This work is entirely my personal effort and does not involve any other parties.