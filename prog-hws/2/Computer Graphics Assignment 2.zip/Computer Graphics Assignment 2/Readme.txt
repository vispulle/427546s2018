Author: Viswanath Pulle
ID: 01690370

Title: Assignment 2

Files included: 
1. Question1-fractals.html
2. Question2-WheelDesign.html
3. ReadMe.txt

Procedure Question 1:
1. Choose the Shape to draw
2. Choose the the ratio or the division of points
3. Choose the number of iterations
4. Click submit
5. To Erase click the "CLEAR" button

Extra Credit:
1. Implemented a fractal tree
2. You may change the color or linewidth as well
3. nicer design labels 
note: For fractal tree, the best view happens at 8 iterations, and linewidth 3

Note: For fractal tree, the best view happens at 8 iterations, and linewidth 3

Procedure Question 2:
1. Enter the driver score between 1 and 100
2. Enter the radius between 1 and 100
3. click the Submit button
4. To Erase click the "CLEAR" button.

Extra credit:
1. Nicer rims
2. Ability to change the line width and color



This work is entirely my personal effort and does not involve any other parties.