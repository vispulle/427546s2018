var canvas = document.getElementById("testCanvas");
var can = canvas.getContext("2d");
var line = document.getElementById("linewidth");
var fillstyle = document.getElementById("color");

function test()
{
	can.clearRect(0,0,canvas.width,canvas.height);
	var x = document.getElementById("form1"),
		radius = x.elements["radius"].value,
		driver_score =x.elements["driver_score"].value;	
	can.lineWidth = document.getElementById("linewidth").value;
	can.strokeStyle=document.getElementById("color").value;
	
	

	if(driver_score == 100)
	{
	
        can.save(); 
        can.beginPath();
        can.arc(400,300,2*radius,2*radius,0,Math.PI*2,false);
        can.stroke();
        can.beginPath();
        can.arc(400,300,2*radius-60,2*radius-60,0,Math.PI*2,false);
        can.stroke();
        
        wheelRim(400,300,radius);
        can.closePath();
			
	}

	else if (driver_score >= 80 && driver_score < 100)
	{
		
			
		var temp = 100 - driver_score, radius2=radius-((temp*radius)/100);

		can.beginPath();
		can.ellipse(400, 300, 2*radius, 2*radius2, 45 * Math.PI/180, 0, 2 * Math.PI);
		can.stroke();
		can.beginPath();
	    can.ellipse(400, 300, 2*radius-60, 2*radius2-60, 45 * Math.PI/180, 0, 2 * Math.PI);
	    can.stroke();		
	    wheelRim(400,300,radius)
	    can.closePath();


        
	}

	else if (driver_score >= 0 && driver_score < 80) {
		var Xcenter = 400,
		    Ycenter = 300;
		wheelRim(400,300,radius);
		can.beginPath();
		can.moveTo (Xcenter +  2*radius * Math.cos(0), Ycenter +  2*radius *  Math.sin(0));          

		for (var i = 1; i <= driver_score;i += 1) {
		    can.lineTo (Xcenter + 2*radius * Math.cos(i * 2 * Math.PI / driver_score), Ycenter + 2*radius * Math.sin(i * 2 * Math.PI / driver_score));
		}

		can.strokeStyle = "#000000";
		//can.lineWidth = 10;
		can.stroke();
		can.closePath();
		can.beginPath();

		can.moveTo (Xcenter +  2*(radius-30) * Math.cos(0), Ycenter +  2*(radius-30) *  Math.sin(0));          

		for (var i = 1; i <= driver_score;i += 1) {
		    can.lineTo (Xcenter + 2*(radius-30) * Math.cos(i * 2 * Math.PI / driver_score), Ycenter + 2*(radius-30) * Math.sin(i * 2 * Math.PI / driver_score));
		}

		can.strokeStyle = "#000000";
		//can.lineWidth = 10;
		can.stroke();
		can.closePath();

	};

	function wheelRim(x,y,radius)
{
	can.fillstyle = document.getElementById("color").value;
    can.save();
    can.beginPath();
    can.arc(x,y,50,50,0,Math.PI*2,false);
    can.stroke();
    can.beginPath();
    can.stroke();
    can.beginPath();
    can.arc(x,y-70,10,10,0,Math.PI*2,false);
    can.stroke();
    can.beginPath();
    can.arc(x-70*Math.cos(52.5*Math.PI / 180),y+70*Math.sin(52.5*Math.PI / 180),10,10,0,Math.PI*2,false);
    can.stroke();
    can.beginPath();
    can.arc(x+70*Math.cos(52.5*Math.PI / 180),y+70*Math.sin(52.5*Math.PI / 180),10,10,0,Math.PI*2,false);
    can.stroke();
    can.beginPath();
    can.arc(x+70*Math.cos(15*Math.PI / 180),y-70*Math.sin(15*Math.PI / 180),10,10,0,Math.PI*2,false);
    can.stroke();
    can.beginPath();
    can.arc(x-70*Math.cos(15*Math.PI / 180),y-70*Math.sin(15*Math.PI / 180),10,10,0,Math.PI*2,false);
    can.stroke();
    can.closePath();
};

};
function clearCanvas(){
	can.clearRect(0,0, canvas.width, canvas.height);
};

